# 02 Bases de Node


Correr en Dev
```
npm run dev
```